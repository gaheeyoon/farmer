#!/bin/bash
set -eu
source_dir="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$HOME/Applications"
/usr/bin/ditto "$source_dir/고구맙습니다 문자발송.app" "$HOME/Applications/고구맙습니다 문자발송.app"
/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister -f "$HOME/Applications/고구맙습니다 문자발송.app"
/usr/bin/open https://yoongahee.com/farmer/admin
printf '\n설치했습니다. 관리자 문자 발송에서 이 Mac을 연결해 주세요.\n'
